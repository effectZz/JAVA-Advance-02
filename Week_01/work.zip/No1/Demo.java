/**
 * @author：ZhaoWenXin
 * @date：2021-03-21 16:33
 */
public class Demo {
    public static void main(String[] args) {
        int a = 10;
        int b = 20;

        for (int i = 0; i < 10; i++) {
            System.out.println(i);
        }
        int c = a + b;
        if (c > 0) {
            System.out.println("1");
        }
    }
}
